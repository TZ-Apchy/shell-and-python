#!/bin/bash
game=(石头 剪刀 布)
num=$[RANDOM%3]
computer=${game[$num]}
echo "请根据下列提示选择您的出拳手势"
echo "1.石头"
echo "2.剪刀"
echo "1.布"
read -p "请选择1-3：" person
case $person in
1)
   if [ $num -eq 0 ];then
      echo "计算机的输入：$computer"
      echo "平局"
   elif [ $num -eq 1 ];then
      echo "计算机的输入：$computer"
      echo "你赢"
   else
      echo "计算机的输入：$computer"
      echo "计算机赢"
   fi;;
2)
   if [ $num -eq 0 ];then
      echo "计算机的输入：$computer"
      echo "计算机赢"
   elif [ $num -eq 1 ];then
      echo "计算机的输入：$computer"
      echo "平局"
   else
      echo "计算机的输入：$computer"
      echo "你赢"
   fi;;
3)
   if [ $num -eq 0 ];then
      echo "计算机的输入：$computer"
      echo "你赢"
   elif [ $num -eq 1 ];then
      echo "计算机的输入：$computer"
      echo "计算机赢"
   else
      echo "计算机的输入：$computer"
      echo "平局"
   fi;;
*)
   echo "必须输入1-3的数字"
esac

