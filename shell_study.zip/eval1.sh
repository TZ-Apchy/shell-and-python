#!/bin/bash
val=100
echo "$val"
eval echo "$val"
