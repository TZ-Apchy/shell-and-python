#!/bin/bash
#批量修改文件名后缀
for i in $(ls *.txt)
do
   mv $i ${i%.*}.doc
done
