#!/bin/bash
#当i取到3时，执行return，会退出当前函数，并且函数中return后的语句也不会被执行，但函数外的语句执行不受影响，即最后的echo语句会被执行；return后面可以带返回值，也可以不带，return常用在函数中，用在非函数的情况会报错，否则执行时需要先source加载脚本再去执行才可以
re() {
	for i in {1..5}
	do
   		[ $i -eq 3 ] && return
   		echo "$i"
	done
}
re
echo "over"
