#!/bin/bash
case $1 in
1)
	echo "yes"
 	;;
2)
	echo "no"
	;;
*)
	echo "ok"
	;;
esac
