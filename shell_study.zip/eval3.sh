#!/bin/bash
curr=$(cd $(dirname $0);pwd)
echo "$curr"
myfile="cat $curr/a.txt"
eval "$myfile"
