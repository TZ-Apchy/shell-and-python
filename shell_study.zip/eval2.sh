#!/bin/bash
pipe="|"
eval "ls $pipe wc -l"
