#!/bin/bash
echo "$0 $1 $2"
echo 1$#
echo $*
echo $@
