#日志文件
LOG_FILE=./log.txt
 
function log()
{
   content="$(date '+%Y-%m-%d %H:%M:%S') $@"
   echo $content >> $LOG_FILE
}

log "tang" "zhi"
