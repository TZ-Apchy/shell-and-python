#!/bin/bash
 
function log()
{
   echo "$(date '+%Y-%m-%d %H:%M:%S') $@"
}
 
log "this is a test..."
