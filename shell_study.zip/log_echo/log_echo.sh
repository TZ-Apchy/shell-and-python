#!/bin/bash
log_type=$1
shift
log_echo ()
{
if [ $log_type == "INFO" ];then
	echo "[INFO]  $(date +%Y-%m-%d) $@"

fi

}

log_echo "tangzhi"
