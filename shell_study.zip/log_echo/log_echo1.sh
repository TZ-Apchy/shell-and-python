#!/bin/bash
 
function log()
{
   echo "$@"
}
# 测试
log "this is a test..."
log "today is `date '+%Y-%m-%d'` "
