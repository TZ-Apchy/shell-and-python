#!/bin/bash
declare -i m n sum  #将多个变量声明为整数
m=10
n=30
sum=m+n
#sum=$m+$n
echo $sum
