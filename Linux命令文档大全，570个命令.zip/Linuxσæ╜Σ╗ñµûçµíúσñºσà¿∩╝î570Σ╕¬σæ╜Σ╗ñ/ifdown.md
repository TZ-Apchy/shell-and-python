ifdown
===

禁用指定的网络接口

## 补充说明

**ifdown命令** 用于禁用指定的网络接口。

###  语法

```shell
ifdown(参数)
```

###  参数

网络接口：要禁用的网络接口。

###  实例

```shell
ifdown eth0  #禁用eth0
```


