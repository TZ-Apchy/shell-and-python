nisdomainname
===

显示主机NIS的域名

## 补充说明

**nisdomainname命令** 用于显示主机NIS的域名。

###  语法

```shell
nisdomainname(选项)
```

###  选项

```shell
-v：详细信息模式。
```


