ypdomainname
===

显示主机的NIS的域名

## 补充说明

**ypdomainname命令** 显示主机的NIS的域名。

###  语法

```shell
ypdomainname(选项)
```

###  选项

```shell
-v：详细信息模式。
```


