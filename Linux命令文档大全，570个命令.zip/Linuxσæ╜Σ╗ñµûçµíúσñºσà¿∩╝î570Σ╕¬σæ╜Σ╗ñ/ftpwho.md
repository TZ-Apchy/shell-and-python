ftpwho
===

显示当前每个ftp会话信息

## 补充说明

**ftpwho命令** ftp服务器套件proftpd的工作指令，用于显示当前每个ftp会话信息。

###  语法

```shell
ftpwho(选项)
```

###  选项

```shell
-h：显示帮助信息；
-v：详细模式，输出更多信息。
```


