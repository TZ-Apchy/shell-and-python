#!/bin/bash
#可以直接通过函数名来定义函数
function msg {
  echo "hello world"
  echo "computer cloud"
}
msg
