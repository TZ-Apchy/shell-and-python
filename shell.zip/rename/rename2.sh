#!/bin/bash
#批量修改文件名后缀，利用传递参数的方式更加灵活
for i in $(ls *.$1)
do
   mv $i ${i%.*}.$2
done
