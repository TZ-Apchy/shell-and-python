#!/bin/bash

if [ $1 -eq 1 ];then
	echo "yes"
elif [ $1 -eq 2 ]
then
	echo "no"
fi


