#!/bin/bash
for i in 1 8 ab 99 qq
do
  	echo "I am $i"
done
