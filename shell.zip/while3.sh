#!/bin/bash
while :
do
     echo "hello world"
     sleep 5

done
