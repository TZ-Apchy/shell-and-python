#!/bin/bash
#这里不是条件判断，无需在双括号左右加上空格
for ((i=1;i<=5;i++))
do
  	echo "I am $i"
done
