#!/bin/bash
#可以直接通过函数名来定义函数
imsg() {
  echo "hello world"
  echo "computer cloud"
}
imsg
